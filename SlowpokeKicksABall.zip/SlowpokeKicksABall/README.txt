Press W to move forward
Press S to move backward
Press A to turn left
Press D to turn right
Press UP to zoom in
Press DOWN to zoom out

Use mouse drag to change camera angles
Use slowpoke to kick the balls
