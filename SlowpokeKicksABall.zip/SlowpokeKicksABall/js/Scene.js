"use strict";
/* exported Scene */
class Scene extends UniformProvider {
  constructor(gl) {
    super("scene");
    this.programs = [];

    this.shadowMatrix = new Mat4();
    this.shadowMatrix.set()
    .scale(new Vec3(1, 0, 1))
    .translate(new Vec3(0, 0.01, 0));

    this.fsTextured = new Shader(gl, gl.FRAGMENT_SHADER, "textured-fs.glsl");
    this.vsTextured = new Shader(gl, gl.VERTEX_SHADER, "textured-vs.glsl"); 
    this.fsBg = new Shader(gl, gl.FRAGMENT_SHADER, "background-fs.glsl");
    this.vsBg = new Shader(gl, gl.VERTEX_SHADER, "background-vs.glsl");
    this.fsPlane = new Shader(gl, gl.FRAGMENT_SHADER, "plane-fs.glsl");
    this.fsShadow = new Shader(gl, gl.FRAGMENT_SHADER, "shadow-fs.glsl"); 
    this.vsShadow = new Shader(gl, gl.VERTEX_SHADER, "shadow-vs.glsl");
    this.fsWood = new Shader(gl, gl.FRAGMENT_SHADER, "wood-fs.glsl")

    this.programs.push( 
    	this.texturedProgram = new TexturedProgram(gl, this.vsTextured, this.fsTextured));
    this.programs.push(
    	this.bgProgram =  new TexturedProgram(gl, this.vsBg, this.fsBg));
    this.programs.push(
        this.planeProgram = new TexturedProgram(gl, this.vsTextured, this.fsPlane));
    this.programs.push(
        this.shadowProgram = new TexturedProgram(gl, this.vsShadow, this.fsShadow));
    this.programs.push(
        this.woodProgram = new TexturedProgram(gl, this.vsTextured, this.fsWood));

    this.texturedQuadGeometry = new TexturedQuadGeometry(gl);
    this.infinitePlaneGeometry = new InfinitePlaneGeometry(gl);

    this.timeAtFirstFrame = new Date().getTime();
    this.timeAtLastFrame = this.timeAtFirstFrame;

    this.shadowMaterial = new Material(this.shadowProgram);
    this.shadowMaterial.solidColor.set(0,0,0,0.1);

    this.woodMaterial = new Material(this.woodProgram);
    this.woodMaterial.freq = 14;
    this.woodMaterial.noiseFreq = 22;
    this.woodMaterial.noiseExp = -0.7;
    this.woodMaterial.noiseAmp = 8;

    this.material1 = new Material(this.texturedProgram);
    this.material2 = new Material(this.texturedProgram);
    this.material1.colorTexture.set(new Texture2D(gl, "media/slowpoke/YadonDh.png"));
    this.material2.colorTexture.set(new Texture2D(gl, "media/slowpoke/YadonEyeDh.png"));

    this.ballMaterial = new Material(this.texturedProgram);
    this.ballMaterial.colorTexture.set(new Texture2D(gl,"media/ball/ball.png"));

    this.bgMaterial =  new Material(this.bgProgram);
    this.envTexture = new TextureCube(gl, [
    	"media/posx.jpg",
    	"media/negx.jpg",
    	"media/posy.jpg",
    	"media/negy.jpg",
    	"media/posz.jpg",
    	"media/negz.jpg",]
    );
    this.bgMaterial.envTexture.set(this.envTexture);

    this.planeMaterial = new Material(this.planeProgram);
    this.planeMaterial.colorTexture.set(new Texture2D(gl,"media/pattern.png"));

    this.materials = [];
    this.materials.push(this.material1);
    this.materials.push(this.material2);
    this.ballMaterials = [];
    this.ballMaterials.push(this.ballMaterial);
    this.woodballMaterials = [];
    this.woodballMaterials.push(this.woodMaterial);

    this.multimesh = new MultiMesh(gl,"media/slowpoke/Slowpoke.json",this.materials);
    this.bgMesh =  new Mesh(this.bgMaterial, this.texturedQuadGeometry);
    this.planeMesh =  new Mesh(this.planeMaterial, this.infinitePlaneGeometry);
    this.ballMesh = new MultiMesh(gl,"media/ball/sphere.json",this.ballMaterials);
    this.woodballMesh = new MultiMesh(gl,"media/ball/sphere.json",this.woodballMaterials);

    this.gameObjects = [];

    const ballUpdate = function(){
        this.modelMatrix.set().
        scale(this.scale).
        mul(this.orientation).
        translate(this.position);
    }

    const rolling = function(t, dt){
        this.position.addScaled(dt, this.velocity);
        const axis = this.velocity.cross(new Vec3(0,1,0)).direction();
        const rotateAngle = -1*this.velocity.length()/this.radius;
        this.orientation.rotate(rotateAngle*dt,axis);
        this.velocity.mul(Math.pow(this.drag,dt));
    }

    const ballControl = function(t, dt, keysPressed, colliders){
        for (const collider of colliders){
            if (collider===this){
                continue;
            }
            let diff = this.position.minus(collider.position);
            diff.y = 0;
            let dist2 = diff.dot(diff);
            let rr = this.radius+collider.radius;
            if (dist2<rr) {
                const restitutionCoeff = 0.8;
                const normal = diff.direction();
                this.position.addScaled(dt,normal);
                if (!collider.isAvatar)
                {
                    collider.position.addScaled(-1*dt,normal);
                }
                const relativeVelocity = this.velocity.minus(collider.velocity);
                const impMag = normal.dot(relativeVelocity)/4*(1+restitutionCoeff);
                this.velocity.addScaled(-1*impMag/2,normal);
                if (!collider.isAvatar)
                {
                    collider.velocity.addScaled(1*impMag/2,normal);
                }
            }
        }
    }

    const avatarControl = function(t, dt, keysPressed, colliders){
        if(keysPressed.D) { 
            this.yaw-=dt*1.5;
        } 
        if(keysPressed.A) { 
            this.yaw+=dt*1.5;
        }
        const speed = 5;
        const ahead = new Vec3(Math.sin(this.yaw),0,Math.cos(this.yaw));
        this.velocity = ahead.mul(speed);
        if(keysPressed.W) { 
            this.position.addScaled(dt, this.velocity)
        } 
        if(keysPressed.S) { 
            this.position.addScaled(-1*dt, this.velocity);
        } 
    }

    this.slowpoke = new GameObject(this.multimesh);
    this.slowpoke.position.z = -5;
    this.slowpoke.scale.set(0.2,0.2,0.2);
    this.slowpoke.noShadow = false;
    this.slowpoke.radius = 2.5;
    this.slowpoke.control = avatarControl;
    this.isAvatar = true;
    this.gameObjects.push(this.slowpoke);

    this.football = new GameObject(this.ballMesh);
    this.football.noShadow = false;
    this.football.scale.set(0.3,0.3,0.3);
    this.football.position.y=0.311;
    this.football.radius = 0.311;
    this.football.position.x=-2;
    this.football.control = ballControl;
    this.football.move = rolling;
    this.football.update = ballUpdate;
    this.gameObjects.push(this.football);

    this.woodball = new GameObject(this.woodballMesh);
    this.woodball.noShadow = false;
    this.woodball.scale.set(2,2,2);
    this.woodball.position.x=2;
    this.woodball.position.y=2.011;
    this.woodball.radius=2.011;
    this.woodball.control = ballControl;
    this.woodball.move = rolling;
    this.woodball.update = ballUpdate;
    this.gameObjects.push(this.woodball);

    this.background =  new GameObject(this.bgMesh);
    this.background.update = function(){};
    this.gameObjects.push(this.background);

    this.plane = new GameObject(this.planeMesh);
    this.plane.pitch = Math.PI/2;
    this.plane.update();
    this.plane.update = function(){};
    this.gameObjects.push(this.plane);

    this.camera = new ThirdPersonCamera(this.slowpoke, ...this.programs); 
    
    this.addComponentsAndGatherUniforms(gl);

    gl.enable(gl.DEPTH_TEST);
  }

  resize(gl, canvas) {
    gl.viewport(0, 0, canvas.width, canvas.height);
    this.camera.setAspectRatio(canvas.width / canvas.height);
  }

  update(gl, keysPressed) {
    //jshint bitwise:false
    //jshint unused:false
    const timeAtThisFrame = new Date().getTime();
    const dt = (timeAtThisFrame - this.timeAtLastFrame) / 1000.0;
    const t = (timeAtThisFrame - this.timeAtFirstFrame) / 1000.0; 
    this.timeAtLastFrame = timeAtThisFrame;
    this.time = t;

    // clear the screen
    gl.clearColor(0.3, 0.0, 0.3, 1.0);
    gl.clearDepth(1.0);
    gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);

    this.camera.move(dt,keysPressed);
    this.camera.update();


    for(const gameObject of this.gameObjects) {
        gameObject.control(t, dt, keysPressed, this.gameObjects);
    }

    for(const gameObject of this.gameObjects) {
        gameObject.move(t,dt);
    }

    for(const gameObject of this.gameObjects) {
        gameObject.update();
    }
    for(const gameObject of this.gameObjects) {
        gameObject.draw(this, this.camera);
    }

    for(const gameObject of this.gameObjects) {
        if(!gameObject.noShadow){ // ground, background need no shadow
            gameObject.using(this.shadowMaterial).draw(this, this.camera);
        }
    }
  }
}
