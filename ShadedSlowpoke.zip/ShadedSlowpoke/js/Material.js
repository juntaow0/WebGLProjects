"use strict"; 
/* exported Material */
class Material extends UniformProvider {
  constructor(program) { 
    super("material");
    this.freq = 1;
    this.noiseFreq = 1;
    this.noiseExp = 1;
    this.noiseAmp = 1;
    this.specularColor = new Vec3();
    this.shininess = 0;
    this.addComponentsAndGatherUniforms(program);
    return onlyWarnOnMissingPropertyAccess(this);
  }
}