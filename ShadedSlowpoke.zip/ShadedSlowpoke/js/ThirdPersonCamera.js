"use strict";
/* exported ThirdPersonCamera */
class ThirdPersonCamera extends UniformProvider {
  constructor(avatar, ...programs) { 
    super("camera");
    this.avatar = avatar;
    this.zoom = 10;
    this.angleAround = 0;
    this.position = new Vec3(0, 0, 3); 
    this.roll = 0;
    this.pitch = Math.PI/5;
    this.yaw = 0;  
           
    this.fov = 1.0; 
    this.aspect = 1.0; 
    this.nearPlane = 0.1; 
    this.farPlane = 1000.0; 
    this.viewProjMatrix = new Mat4(); 
    this.rayDirMatrix = new Mat4();
    this.viewMatrix = new Mat4();
  
    this.isDragging = false; 
    this.mouseDelta = new Vec2(0.0, 0.0);

    this.ahead = new Vec3(0.0, 0.0, -1.0); 
    this.right = new Vec3(1.0, 0.0, 0.0); 
    this.up = new Vec3(0.0, 1.0, 0.0);
    this.worldUp = new Vec3(0, 1, 0);
    this.worldPosition = new Vec3();
    
    this.update();
 
    this.addComponentsAndGatherUniforms(...programs);
  }
  update() {

    this.ahead = this.avatar.position.minus(this.position);
    this.ahead.normalize();
    this.right.setVectorProduct(this.ahead, this.worldUp); 
    this.right.normalize(); 
    this.up.setVectorProduct(this.right, this.ahead); 

    this.viewMatrix.set( 
    this.right.x  ,  this.right.y ,  this.right.z  , 0, 
    this.up.x     ,  this.up.y    ,  this.up.z     , 0, 
   -this.ahead.x  , -this.ahead.y , -this.ahead.z  , 0, 
    0             ,  0            , 0              , 1).
                                translate(this.position).
                                invert();
       
    this.viewProjMatrix.set(this.viewMatrix);

      const yScale = 1.0 / Math.tan(this.fov * 0.5); 
      const xScale = yScale / this.aspect; 
      const f = this.farPlane; 
      const n = this.nearPlane; 
    this.viewProjMatrix.mul( 
      new Mat4( 
        xScale ,    0    ,      0       ,   0, 
          0    ,  yScale ,      0       ,   0, 
          0    ,    0    ,  (n+f)/(n-f) ,  -1, 
          0    ,    0    ,  2*n*f/(n-f) ,   0)); 

    this.rayDirMatrix.set().translate(this.position).mul(this.viewProjMatrix).invert();
    this.worldPosition.set(this.position);
  } 
  setAspectRatio(ar) { 
    this.aspect = ar; 
    this.update(); 
  }
  move(dt, keysPressed) { 
    
    if(this.isDragging){ 
      
      this.pitch += this.mouseDelta.y * 0.002;
      this.yaw -= this.mouseDelta.x * 0.002;
      this.angleAround -= this.mouseDelta.x * 0.002;
      if(this.pitch > 3.14/2.0) { 
        this.pitch = 3.14/2.0; 
      } 
      if(this.pitch < 0.1) { 
        this.pitch = 0.1; 
      }
      this.mouseDelta = new Vec2(0.0, 0.0);
    }
    if (keysPressed.UP){
      this.zoom-=dt*4;
    }else if(keysPressed.DOWN){
      this.zoom+=dt*4;
    }
    if (this.zoom<4){
      this.zoom=4;
    }
    if (this.zoom>15){
      this.zoom=15;
    }

    this.calculatePos();
    this.update();
  } 
  mouseDown() { 
    this.isDragging = true; 
    this.mouseDelta.set(); 
  } 
  mouseMove(event) { 
    this.mouseDelta.x += event.movementX; 
    this.mouseDelta.y += event.movementY; 
    event.preventDefault();  
  } 
  mouseUp() { 
    this.isDragging = false; 
  }
  calculatePos(){
    const yOffset = this.zoom * Math.sin(this.pitch);
    const horizontal = this.zoom * Math.cos(this.pitch);
    const xOffset = horizontal * Math.sin(this.angleAround+this.avatar.yaw);
    const zOffset = horizontal * Math.cos(this.angleAround+this.avatar.yaw);
    
    this.position.y = this.avatar.position.y + yOffset;
    this.position.x = this.avatar.position.x - xOffset;
    this.position.z = this.avatar.position.z - zOffset;
  } 
} 
