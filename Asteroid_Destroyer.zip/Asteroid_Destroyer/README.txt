Press SPACE to shoot
Press UP to accelerate
Press DOWN to decelerate
Press LEFT to turn left
Press RIGHT to turn right

Unlimited Asteroids
1.5 second canon cooldown
Ship explodes on collision
Area is restricted and will wrap around
	expect sudden appearance of asteroids
