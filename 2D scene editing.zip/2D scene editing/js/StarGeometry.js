"use strict";
/* exported StarGeometry */
class StarGeometry {
  constructor(gl) {
    this.gl = gl;
    this.radius = 1;
    this.R = 1/(1.618033988749895+1);

    // allocate and fill vertex buffer in device memory (OpenGL name: array buffer)
    this.vertexBuffer = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, this.vertexBuffer);
    var starArray = [0.0,0.0,0.0]
    var index = 0;
    for (let phi = 0; phi < 2*Math.PI; phi+=(2*Math.PI)/10)
    {
      if (index%2){
        starArray.push(this.radius*Math.cos(phi), this.radius*Math.sin(phi),0);
      } else{
        starArray.push(this.R*Math.cos(phi), this.R*Math.sin(phi),0);
      }
      index++;
    }

    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(starArray), gl.STATIC_DRAW);

    // allocate and fill index buffer in device memory (OpenGL name: element array buffer)
    this.indexBuffer = gl.createBuffer();
    gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, this.indexBuffer);
    var indexArray = [];
    for (let step = 0; step<11;step++)
    {
      indexArray.push(0,step+1,(step+1)%10+1);
    }

    gl.bufferData(gl.ELEMENT_ARRAY_BUFFER,new Uint16Array(indexArray),gl.STATIC_DRAW);

    // create and bind input layout with input buffer bindings (OpenGL name: vertex array)
    this.inputLayout = gl.createVertexArray();
    gl.bindVertexArray(this.inputLayout);

    gl.bindBuffer(gl.ARRAY_BUFFER, this.vertexBuffer);
    gl.enableVertexAttribArray(0);
    gl.vertexAttribPointer(0,
      3, gl.FLOAT, //< three pieces of float
      false, //< do not normalize (make unit length)
      0, //< tightly packed
      0 //< data starts at array start
    );

    gl.bindVertexArray(null);
  }

  draw() {
    const gl = this.gl;

    gl.bindVertexArray(this.inputLayout);
    gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, this.indexBuffer);  

    gl.drawElements(gl.TRIANGLES, 30, gl.UNSIGNED_SHORT, 0);
  }
}
