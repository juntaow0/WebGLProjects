"use strict"; 
/* exported Mesh */
class Mesh extends UniformProvider {
  constructor(material, geometry) {
    super("mesh");
    this.radius = geometry.radius;
    this.addComponentsAndGatherUniforms(material, geometry);
  }
}
