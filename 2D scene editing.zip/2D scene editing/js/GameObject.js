"use strict"; 
/* exported GameObject */
class GameObject extends UniformProvider {
  constructor(mesh) { 
    super("gameObject");
    this.position = new Vec3(0, 0, 0); 
    this.orientation = 0; 
    this.scale = new Vec3(1, 1, 1); 
    this.radius = mesh.radius;
    this.xOffset = 0;
    this.yOffset = 0;
    this.usefulRadius = null;
    this.addComponentsAndGatherUniforms(mesh);
  } 
  update(){
  	this.modelMatrix = new Mat4().scale(this.scale).rotate(this.orientation).translate(this.position);
  }

  inRange(downCoord,upCoord){
    this.usefulRadius = this.radius*this.scale.x;
    var xRange = [downCoord.x,upCoord.x];
    var yRange = [downCoord.y,upCoord.y];

    if (downCoord.x>upCoord.x){
      xRange = xRange.reverse();
    }
    if (downCoord.y>upCoord.y){
      yRange = yRange.reverse();
    } 
    return (((xRange[0] <= this.position.x+this.usefulRadius/(1.61+1)) && (this.position.x-this.usefulRadius/(1.61+1) <= xRange[1])) 
      && ((yRange[0] <= this.position.y+this.usefulRadius/(1.61+1)) && (this.position.y-this.usefulRadius/(1.61+1) <= yRange[1])));
  }

  onObject(mouseCoord){
    var distance = Math.sqrt(Math.pow(mouseCoord.x-this.position.x,2)+Math.pow(mouseCoord.y-this.position.y,2));
    this.usefulRadius = this.radius*this.scale.x;
    return (distance<=this.usefulRadius/(1.61+1));
  }
}
