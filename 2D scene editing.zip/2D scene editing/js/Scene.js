"use strict";
/* exported Scene */
class Scene extends UniformProvider {
  constructor(gl) {
    super("scene");
    
    this.vsIdle = new Shader(gl, gl.VERTEX_SHADER, "idle-vs.glsl");
    this.fsStripe = new Shader(gl, gl.FRAGMENT_SHADER, "stripe-fs.glsl");
    this.fsWheel = new Shader(gl, gl.FRAGMENT_SHADER, "wheel-fs.glsl");
    this.stripeProgram = new Program(gl, this.vsIdle, this.fsStripe);
    this.wheelProgram = new Program(gl, this.vsIdle, this.fsWheel);

    this.programs = [this.stripeProgram, this.wheelProgram];
    this.camera = new OrthoCamera(...this.programs);

    this.materialHighlight =  new Material(this.stripeProgram);
    this.materialHighlight.stripeColor.set(0,0.9,0.9);
    this.materialHighlight.stripeWidth=0;
    this.normalStripe =  new Material(this.stripeProgram);
    this.normalStripe.stripeColor.set(0,0.5,0.9);
    this.normalStripe.stripeWidth=5;
    this.normalWheel = new Material(this.wheelProgram);
    this.normalWheel.wheelColor.set(0,0.7,0.7);
    this.starGeometry = new StarGeometry(gl);

    this.stripeMesh = new Mesh(this.normalStripe, this.starGeometry);
    this.wheelMesh = new Mesh(this.normalWheel, this.starGeometry);

    this.gameObject1 = new GameObject(this.stripeMesh);
    this.gameObject2 = new GameObject(this.wheelMesh);
    this.gameObject1.scale.set(0.4,0.4,0.4);
    this.gameObject1.position.set(0.5,0.5,0.0);
    this.gameObject1.orientation = 3*Math.PI/2;
    this.gameObject2.scale.set(0.4,0.4,0.4);
    this.gameObject2.position.set(-0.5,0.5,0.0);
    this.gameObject2.orientation = 3*Math.PI/2;

    this.gameObjects = [this.gameObject1,this.gameObject2];
    this.selectedObjects = [];
    this.addComponentsAndGatherUniforms(...this.programs);

    this.timeAtFirstFrame = new Date().getTime();
    this.timeAtLastFrame = this.timeAtFirstFrame;

    this.collectRange = false;
    this.dragMode = false;
    this.cameraMode = false;
    this.prevSpace = false;
    this.prevAlt = false;
    this.prevDown=false;
    this.downCoord = null;
    this.prevCoord = null;
  }

  resize(gl, canvas) {
    gl.viewport(0, 0, canvas.width, canvas.height);
    this.camera.setAspectRatio(canvas.clientWidth/canvas.clientHeight);
  }

  update(gl, keysPressed, mouseDown, mouseCoord){
    // jshint bitwise:false
    // jshint unused:false

    // time passed and absolute time
    const timeAtThisFrame = new Date().getTime();
    const dt = (timeAtThisFrame - this.timeAtLastFrame) / 1000.0;
    const t = (timeAtThisFrame - this.timeAtFirstFrame) / 1000.0;
    this.timeAtLastFrame = timeAtThisFrame;

    // clear the screen
    gl.clearColor(0.412, 0.412, 0.412,1.0);
    gl.clearDepth(1.0);
    gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);

    // check mouse position and select operation
    if (mouseDown){
      if (mouseDown!==this.prevDown){ // mousedown first time
        this.downCoord = mouseCoord;
      }
      if (keysPressed["ALT"]){
        this.cameraMode = true;
        this.dragMode = false;
        this.collectRange = false;
      } else {
        this.cameraMode = false;
        for (const gameObject of this.selectedObjects){
          if (gameObject.onObject(this.downCoord)){
            this.dragMode = true;
            break;
          }
        }
        if (!this.dragMode){
          this.collectRange = true;
        }
      }
    } else {
      this.cameraMode = false;
      this.dragMode = false;
      if (this.collectRange){
        this.selectedObjects = [];
        this.collectRange = false;
        for (const gameObject of this.gameObjects){
          if (gameObject.inRange(this.downCoord,mouseCoord)){
            this.selectedObjects.push(gameObject);
          }
        }
      }
    }

    // drag camera
    if (this.cameraMode&&(this.prevCoord!==mouseCoord)){
      this.camera.position.x+=(this.downCoord.x-mouseCoord.x);
      this.camera.position.y+=(this.downCoord.y-mouseCoord.y);
      this.camera.update();
    }

    // delete selected objects
    if (keysPressed["DELETE"]){
      this.gameObjects = this.gameObjects.filter(element => !this.selectedObjects.includes(element));
      this.selectedObjects = [];
    }

    // operations
    for (const gameObject of this.selectedObjects){
      // duplicate
      if ((keysPressed["SPACE"]!==this.prevSpace)&&keysPressed["SPACE"]){
        var duplicated = new GameObject(gameObject);
        duplicated.position.x = gameObject.position.x-0.5; 
        duplicated.position.y = gameObject.position.y-0.5; 
        duplicated.orientation =  gameObject.orientation;
        duplicated.scale = gameObject.scale;
        this.gameObjects.push(duplicated);
      }

      // rotation
      if (keysPressed["A"]){
        gameObject.orientation+=0.5*dt;
      } else if (keysPressed["D"]){
        gameObject.orientation-=0.5*dt;
      }

      // mouse drag
      if ((mouseDown!==this.prevDown)&&this.dragMode){
        gameObject.xOffset = gameObject.position.x-this.downCoord.x;
        gameObject.yOffset = gameObject.position.y-this.downCoord.y; 
      }
      if (this.dragMode){
        gameObject.position.x = mouseCoord.x+gameObject.xOffset;
        gameObject.position.y = mouseCoord.y+gameObject.yOffset;
      }
    }

    // update 
    for (const gameObject of this.gameObjects){
      gameObject.update(this);
      gameObject.draw(this, this.camera);
    }
    for (const gameObject of this.selectedObjects){
      gameObject.using(this.materialHighlight).draw(this, this.camera);
    }
    this.prevSpace = keysPressed["SPACE"];
    this.prevAlt = keysPressed["ALT"];
    this.prevDown = mouseDown;
    this.prevCoord = mouseCoord;
  }
}
