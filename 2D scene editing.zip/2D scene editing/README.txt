To pick: objects within the rectangle spanned by a mouse drag starting and ending points should be selected, or click near the center of an object.

To unselect: click empty area.

To move objects: after picking, click and hold near the center of an objects, and then move mouse. Release to drop the object. Multiple objects can be moved in parallel.

Pan: press "ALT" first, and then click and drag the mouse to move the camera. DO NOT click and then press "ALT".

To rotate: after picking, press "A" or "D" to rotate. Multiple objects can be rotated at the same time.

Press "DEL" to delete selected objects.

Press space bar to duplicate selected objects.

