"use strict";
/* exported HeartGeometry */
class HeartGeometry {
  constructor(gl) {
    this.gl = gl;
    this.maxWidth = 0.0; 
    this.maxHeight = 0.0; 

    // allocate and fill vertex buffer in device memory (OpenGL name: array buffer)
    this.vertexBuffer = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, this.vertexBuffer);
    var heartArray = [0.0,0.0,0.0];
    var width = 0;
    var height = 0;
    for (let phi = 0; phi < 2*Math.PI; phi+=(2*Math.PI)/360)
    {
      var x = Math.sin(phi)*Math.sin(phi)*Math.sin(phi)*16
      var y = 13*Math.cos(phi)-5*Math.cos(2*phi)-2*Math.cos(3*phi)-Math.cos(4*phi)
      heartArray.push(x*0.025,y*0.025,0.0);
      if (Math.abs(x)>width){
        width=Math.abs(x);
      }
      if (Math.abs(y)>height){
        height=Math.abs(y);
      }
    }
    this.maxWidth = width*0.025; 
    this.maxHeight = height*0.025;

    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(heartArray),gl.STATIC_DRAW);

    // allocate and fill index buffer in device memory (OpenGL name: element array buffer)
    this.indexBuffer = gl.createBuffer();
    gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, this.indexBuffer);
    var indexArray = [];
    for (let step = 0; step<360;step++)
    {
      indexArray.push(0,step+1,(step+1)%360+1);
    }
    gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, new Uint16Array(indexArray), gl.STATIC_DRAW);

    this.vertexColor = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, this.vertexColor);
    var colorArray = [];
    for (let step = 0; step<heartArray.length; step++)
    {
      colorArray.push(Math.random(),Math.random(),Math.random())
    }
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(colorArray), gl.STATIC_DRAW);

    // create and bind input layout with input buffer bindings (OpenGL name: vertex array)
    this.inputLayout = gl.createVertexArray();
    gl.bindVertexArray(this.inputLayout);

    gl.bindBuffer(gl.ARRAY_BUFFER, this.vertexBuffer);
    gl.enableVertexAttribArray(0);
    gl.vertexAttribPointer(0,
      3, gl.FLOAT, //< three pieces of float
      false, //< do not normalize (make unit length)
      0, //< tightly packed
      0 //< data starts at array start
    );



    gl.bindBuffer(gl.ARRAY_BUFFER, this.vertexColor);
    gl.enableVertexAttribArray(1);
    gl.vertexAttribPointer(1,
      3, gl.FLOAT, //< three pieces of float
      false, //< do not normalize (make unit length)
      0, //< tightly packed
      0 //< data starts at array start
    );

    gl.bindVertexArray(null);
  }

  draw() {
    const gl = this.gl;

    gl.bindVertexArray(this.inputLayout);
    gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, this.indexBuffer);  

    gl.drawElements(gl.TRIANGLES, 360*3, gl.UNSIGNED_SHORT, 0);
  }
}
