"use strict";
/* exported Scene */
class Scene {
  constructor(gl) {
    this.vsIdle = new Shader(gl, gl.VERTEX_SHADER, "idle-vs.glsl");
    this.fsSolid = new Shader(gl, gl.FRAGMENT_SHADER, "solid-fs.glsl");
    this.fsPattern = new Shader(gl, gl.FRAGMENT_SHADER, "pattern-fs.glsl");
    this.fsMovingPattern = new Shader(gl, gl.FRAGMENT_SHADER, "movingPattern-fs.glsl");
    this.solidProgram = new Program(gl, this.vsIdle, this.fsSolid);
    this.patternProgram = new Program(gl, this.vsIdle, this.fsPattern);
    this.movingPatternProgram = new Program(gl, this.vsIdle, this.fsMovingPattern);
    this.donutGeometry = new DonutGeometry(gl);
    this.heartGeometry = new HeartGeometry(gl);
    this.avatarPosition = {x:0,y:0,z:0};
    this.timeAtFirstFrame = new Date().getTime();
    this.timeAtLastFrame = this.timeAtFirstFrame;
  }

  resize(gl, canvas) {
    gl.viewport(0, 0, canvas.width, canvas.height);
  }

  update(gl, keysPressed) {
    //jshint bitwise:false
    //jshint unused:false

    // clear the screen
    gl.clearColor(0.0, 0.0, 0.3, 1.0);
    gl.clearDepth(1.0);
    gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
    const timeAtThisFrame = new Date().getTime();
    const dt = (timeAtThisFrame - this.timeAtLastFrame) / 1000.0;
    const t = (timeAtThisFrame - this.timeAtFirstFrame) / 1000.0;
    this.timeAtLastFrame = timeAtThisFrame;

    // choose shader
    gl.useProgram(this.solidProgram.glProgram);
    const objectPositionHandle1 = 
      gl.getUniformLocation(this.solidProgram.glProgram,"gameObject.position"); 
    if (objectPositionHandle1 === null) {
      console.log("Could not find uniform: gameObject.position");
    }
    const objectTimeHandle1 = 
      gl.getUniformLocation(this.solidProgram.glProgram,"scene.t"); 
    if (objectTimeHandle1 === null) {
      console.log("Could not find uniform: scene.t");
    }
    const objectDeformHandle1 = 
      gl.getUniformLocation(this.solidProgram.glProgram,"deform.parameters"); 
    if (objectDeformHandle1 === null) {
      console.log("Could not find uniform: deform.parameters");
    }

    gl.uniform2f(objectDeformHandle1,1.0,0.0);
    gl.uniform1f(objectTimeHandle1,t);
    gl.uniform3f(objectPositionHandle1, -0.5,0.5,0);
    this.donutGeometry.draw();
    gl.uniform2f(objectDeformHandle1,2.0,1.0);
    gl.uniform3f(objectPositionHandle1, 0.5,0.5,0);
    this.heartGeometry.draw();

    // choose shader
    gl.useProgram(this.patternProgram.glProgram);
    const objectPositionHandle2 = 
      gl.getUniformLocation(this.patternProgram.glProgram,"gameObject.position"); 
    if (objectPositionHandle2 === null) {
      console.log("Could not find uniform: gameObject.position");
    }
    const objectTimeHandle2 = 
      gl.getUniformLocation(this.patternProgram.glProgram,"scene.t"); 
    if (objectTimeHandle2 === null) {
      console.log("Could not find uniform: scene.t");
    }
    const objectPatternHandle1 = 
      gl.getUniformLocation(this.patternProgram.glProgram,"stripePattern.parameters"); 
    if (objectPatternHandle1 === null) {
      console.log("Could not find uniform: stripePattern.parameters");
    } 
    const objectDeformHandle2 = 
      gl.getUniformLocation(this.patternProgram.glProgram,"deform.parameters"); 
    if (objectDeformHandle2 === null) {
      console.log("Could not find uniform: deform.parameters");
    }

    gl.uniform2f(objectDeformHandle2,1.2,1.0);
    gl.uniform3f(objectPositionHandle2, -0.5,-0.5,0);
    gl.uniform1f(objectTimeHandle2,t);
    gl.uniform3f(objectPatternHandle1, 10,0.3,0.9);
    this.donutGeometry.draw();
    gl.uniform2f(objectDeformHandle2,1.0,0.0);
    gl.uniform3f(objectPositionHandle2, 0.5,-0.5,0);
    gl.uniform3f(objectPatternHandle1, 30,0.6,0.2);
    this.heartGeometry.draw();

    // choose shader
    gl.useProgram(this.movingPatternProgram.glProgram);
    const objectPositionHandle3 = 
      gl.getUniformLocation(this.movingPatternProgram.glProgram,"gameObject.position"); 
    if (objectPositionHandle3 === null) {
      console.log("Could not find uniform: gameObject.position");
    }
    const objectPatternHandle2 = 
      gl.getUniformLocation(this.movingPatternProgram.glProgram,"stripePattern.parameters"); 
    if (objectPatternHandle2 === null) {
      console.log("Could not find uniform: stripePattern.parameters");
    }
    const objectTimeHandle3 = 
      gl.getUniformLocation(this.movingPatternProgram.glProgram,"scene.t"); 
    if (objectTimeHandle3 === null) {
      console.log("Could not find uniform: scene.t");
    }
    const objectDeformHandle3 = 
      gl.getUniformLocation(this.movingPatternProgram.glProgram,"deform.parameters"); 
    if (objectDeformHandle3 === null) {
      console.log("Could not find uniform: deform.parameters");
    }

    gl.uniform2f(objectDeformHandle3,1.5,0.0);
    gl.uniform1f(objectTimeHandle3, t);
    gl.uniform3f(objectPositionHandle3, this.avatarPosition.x,this.avatarPosition.y,this.avatarPosition.z);
    gl.uniform3f(objectPatternHandle2, 50,0.5,0.5);
    this.heartGeometry.draw();
    
    if (this.avatarPosition.x>(1+this.heartGeometry.maxWidth)){
      this.avatarPosition.x = -1-this.heartGeometry.maxWidth;
    } else if (this.avatarPosition.x<(-1-this.heartGeometry.maxWidth)){
      this.avatarPosition.x = 1+this.heartGeometry.maxWidth;
    }

    if (this.avatarPosition.y>(1+this.heartGeometry.maxHeight)){
      this.avatarPosition.y = -1-this.heartGeometry.maxHeight;
    } else if (this.avatarPosition.y<(-1-this.heartGeometry.maxHeight)){
      this.avatarPosition.y = 1+this.heartGeometry.maxHeight;
    }

    if (keysPressed["UP"]===true){
      this.avatarPosition.y += 0.25 * dt;
    } else if (keysPressed["DOWN"]===true){
      this.avatarPosition.y -= 0.25 * dt;
    }

    if (keysPressed["LEFT"]===true){
      this.avatarPosition.x -= 0.25 * dt;
    } else if (keysPressed["RIGHT"]===true){
      this.avatarPosition.x += 0.25 * dt;
    } 
  }
}